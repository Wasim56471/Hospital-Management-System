package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class SplashControler implements Initializable {
	

	public void initialize(URL arg0, ResourceBundle arg1) {
		new SplashScreen().start();
	}
	public void close() {
		Platform.exit();
	}
	
}
class SplashScreen extends Thread {
	@FXML
	private AnchorPane rootPane;
	@Override
	public void run() {
		try {
			Thread.sleep(5000);
			Platform.runLater(new Runnable() {
				@Override
				public void run() {
					Parent root=null;
					try {
						root = FXMLLoader.load(getClass().getResource("/application/Login.fxml"));
					} catch (IOException ex) {
						Logger.getLogger(SplashControler.class.getName()).log(Level.SEVERE, null,ex);
					}
					Scene scene = new Scene(root,700,500);
					scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
					Stage stage= new Stage();
					stage.setScene(scene);
					stage.show();
					
					rootPane.getScene().getWindow().hide();
	
					
				}
			});
			
		
		}catch(Exception ex) {
			Logger.getLogger(SplashControler.class.getName()).log(Level.SEVERE, null,ex);
	}
}
}