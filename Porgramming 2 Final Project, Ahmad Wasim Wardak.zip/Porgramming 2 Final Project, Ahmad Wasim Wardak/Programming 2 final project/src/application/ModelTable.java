package application;

public class ModelTable {
	String id,name,dname,age,diag,treat,diagdate;

	public ModelTable(String id, String name, String dname, String age, String diag, String treat, String diagdate) {
		super();
		this.id = id;
		this.name = name;
		this.dname = dname;
		this.age = age;
		this.diag = diag;
		this.treat = treat;
		this.diagdate = diagdate;
		

}


	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getDiag() {
		return diag;
	}

	public void setDiag(String diag) {
		this.diag = diag;
	}

	public String getTreat() {
		return treat;
	}

	public void setTreat(String treat) {
		this.treat = treat;
	}
	public String getDiagdate() {
		return diagdate;
	}

	public void setDiagdate(String diagdate) {
		this.diagdate = diagdate;
	}
	}

